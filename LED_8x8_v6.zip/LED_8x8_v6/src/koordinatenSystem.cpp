#include "koordinatenSystem.h"

uint8_t koordinate(int x, int y, uint8_t width, uint8_t height)
{

     if (x<0 || x >= width || y<0 || y>=height) return width*height;
        // Special indicator for "out of screen" that goes into one
        // extra entry of the LED-array without causing harm
                    
     if ((y & 1) == 0) {
          return y * width + x; 
     }

     return (y+1) * width - x -1;


}
