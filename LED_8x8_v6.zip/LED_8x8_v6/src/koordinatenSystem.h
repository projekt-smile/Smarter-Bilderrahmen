#ifndef koordinatenSystem_h
#define koordinatensSystem_h

#include <Arduino.h>

uint8_t koordinate(int x, int y, uint8_t width, uint8_t height);


#endif
