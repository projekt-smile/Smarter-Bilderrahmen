#include "alphabet.h"



void clean(uint8_t num_leds){
  CRGB leds[num_leds];
  for(int i=0; i<num_leds; i++){
    leds[i] = CRGB(0,0,0);
  }
  FastLED.show();
}

/* Buchstaben in beliebiger Farbe aufleuchtne lassen*/
void buchstabe(String letter_s, int r, int g, int b, int startX, int startY, uint8_t num_leds, CRGB* leds){
  int x = 0;
  int y = 0;
  char letter = letter_s.charAt(0); 
  switch (letter){
    case 'A':{
      for (int y=startY; y<=startY+5; y++){
        leds[koordinate_(startX,y)] = CRGB(r,g,b);
        leds[koordinate_(startX+4,y)] = CRGB(r,g,b);
      }
      for (int x=startX+1; x<=startX+3; x++){
        leds[koordinate_(x,startY+3)] = CRGB(r,g,b);
        leds[koordinate_(x,startY+6)] = CRGB(r,g,b);
      }      
      FastLED.show();
      break;}
    case 'B':{
      for (int y=startY; y<=startY+6; y++){
        leds[koordinate_(startX,y)] = CRGB(r,g,b);
        if(y!=startY && y!=startY+3 && y!=startY+6)leds[koordinate_(startX+4,y)] = CRGB(r,g,b);
      }
      for (int x=startX+1; x<=startX+3; x++){
        leds[koordinate_(x,startY)] = CRGB(r,g,b);
        leds[koordinate_(x,startY+3)] = CRGB(r,g,b);
        leds[koordinate_(x,startY+6)] = CRGB(r,g,b);
      }
      FastLED.show();  
      break;}
    case 'C':{
      for (int y=startY+1; y<=startY+5; y++){
        leds[koordinate_(startX,y)] = CRGB(r,g,b);
      }
      for (int x=startX+1; x<=startX+3; x++){
        leds[koordinate_(x,startY)] = CRGB(r,g,b);
        leds[koordinate_(x,startY+6)] = CRGB(r,g,b);
      }
      leds[koordinate_(startX+4,startY+1)] = CRGB(r,g,b);
      leds[koordinate_(startX+4,startY+5)] = CRGB(r,g,b);    
      FastLED.show();
      break;}
    case 'D':{
      for (int y=startY; y<=startY+6; y++){
        leds[koordinate_(startX,y)] = CRGB(r,g,b);
        if(y>=startY+1 && y<=startY+5) leds[koordinate_(startX+4,y)] = CRGB(r,g,b);
      }
      for (int x=startX+1; x<=startX+3; x++){
        leds[koordinate_(x,startY)] = CRGB(r,g,b);
        leds[koordinate_(x,startY+6)] = CRGB(r,g,b);
      }   
      FastLED.show();
      break;}
    case 'E':{
      for (int y=startY; y<=startY+6; y++){
        leds[koordinate_(startX,y)] = CRGB(r,g,b);
      }
      for (int x=startX+1; x<=startX+4; x++){
        leds[koordinate_(x,startY)] = CRGB(r,g,b);
        leds[koordinate_(x,startY+6)] = CRGB(r,g,b);
        if (x<startX+4)leds[koordinate_(x,startY+3)] = CRGB(r,g,b);
      }    
      FastLED.show();
      break;}
    case 'F':{
      for (int y=startY; y<=startY+6; y++){
        leds[koordinate_(startX,y)] = CRGB(r,g,b);
      }
      for (int x=startX+1; x<=startX+4; x++){
        leds[koordinate_(x,startY+6)] = CRGB(r,g,b);
        if (x>startX+1)leds[koordinate_(x-1,startY+3)] = CRGB(r,g,b);
      }      
      FastLED.show();
      break;}
    case 'G':{
      for (int y=startY+1; y<=startY+5; y++){
        leds[koordinate_(startX,y)] = CRGB(r,g,b);
        if(y==startY+5)leds[koordinate_(startX+4,y)] = CRGB(r,g,b);
        if(y>startY+1)leds[koordinate_(startX+4,y-2)] = CRGB(r,g,b);
      }
      for (int x=startX+1; x<=startX+3; x++){
        leds[koordinate_(x,startY)] = CRGB(r,g,b);
        leds[koordinate_(x,startY+6)] = CRGB(r,g,b);
        if (x>startX+1)leds[koordinate_(x,startY+3)] = CRGB(r,g,b);
      }    
      FastLED.show();
      break;}
    case 'H':{
      for (int y=startY; y<=startY+6; y++){
        leds[koordinate_(startX,y)] = CRGB(r,g,b);
        leds[koordinate_(startX+4,y)] = CRGB(r,g,b);
      }
      for (int x=startX+1; x<=startX+3; x++){
        leds[koordinate_(x,startY+3)] = CRGB(r,g,b);
      }
      FastLED.show();
      break;}
    case 'I':{
      for (int y=startY+1; y<=startY+5; y++){
        leds[koordinate_(startX+2,y)] = CRGB(r,g,b);
      }
      for (int x=startX+1; x<=startX+3; x++){
        leds[koordinate_(x,startY)] = CRGB(r,g,b);
        leds[koordinate_(x,startY+6)] = CRGB(r,g,b);
      }    
      FastLED.show();
      break;}
    case 'J':{
      for (int y=startY+1; y<=startY+5; y++){
        leds[koordinate_(startX+3,y)] = CRGB(r,g,b);
      }
      for (int x=startX+2; x<=startX+4; x++){
        leds[koordinate_(x,startY+6)] = CRGB(r,g,b);
      }
      leds[koordinate_(startX,startY+1)] = CRGB(r,g,b);
      leds[koordinate_(startX+1,startY)] = CRGB(r,g,b);
      leds[koordinate_(startX+2,startY)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case 'K':{
      for (int y=startY; y<=startY+6; y++){
        leds[koordinate_(startX,y)] = CRGB(r,g,b);
      }
      int hz = 0; //Hilfszähler
      for (int x=startX+1; x<=startX+4; x++){
        leds[koordinate_(x,startY+3+hz)] = CRGB(r,g,b);
        leds[koordinate_(x,startY+3-hz)] = CRGB(r,g,b);
        hz = hz+1;
      }
      FastLED.show();
      break;}
    case 'L':{
      for (int y=startY; y<=startY+6; y++){
        leds[koordinate_(startX,y)] = CRGB(r,g,b);
      }
      for (int x=startX+1; x<=startX+4; x++){
        leds[koordinate_(x,startY)] = CRGB(r,g,b);
      }   
      FastLED.show();
      break;}
    case 'M':{
      for (int y=startY; y<=startY+6; y++){
        leds[koordinate_(startX,y)] = CRGB(r,g,b);
        leds[koordinate_(startX+4,y)] = CRGB(r,g,b);
      }
      leds[koordinate_(startX+1,startY+5)] = CRGB(r,g,b);
      leds[koordinate_(startX+2,startY+4)] = CRGB(r,g,b);
      leds[koordinate_(startX+2,startY+3)] = CRGB(r,g,b);
      leds[koordinate_(startX+3,startY+5)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case 'N':{
      for (int y=startY; y<=startY+6; y++){
        leds[koordinate_(startX,y)] = CRGB(r,g,b);
        leds[koordinate_(startX+4,y)] = CRGB(r,g,b);
      }
      leds[koordinate_(startX+1,startY+4)] = CRGB(r,g,b);
      leds[koordinate_(startX+2,startY+3)] = CRGB(r,g,b);
      leds[koordinate_(startX+3,startY+2)] = CRGB(r,g,b); 
      FastLED.show();
      break;}
    case 'O':{
      for (int y=startY+1; y<=startY+5; y++){
        leds[koordinate_(startX,y)] = CRGB(r,g,b);
        leds[koordinate_(startX+4,y)] = CRGB(r,g,b);
      }
      for (int x=startX+1; x<=startX+3; x++){
        leds[koordinate_(x,startY)] = CRGB(r,g,b);
        leds[koordinate_(x,startY+6)] = CRGB(r,g,b);
      } 
      FastLED.show();
      break;}
    case 'P':{
      for (int y=startY; y<=startY+6; y++){
        leds[koordinate_(startX,y)] = CRGB(r,g,b);
        if(y>startY+4)leds[koordinate_(startX+4,y-1)] = CRGB(r,g,b);
      }
      for (int x=startX+1; x<=startX+3; x++){
        leds[koordinate_(x,startY+3)] = CRGB(r,g,b);
        leds[koordinate_(x,startY+6)] = CRGB(r,g,b);
      }   
      FastLED.show();
      break;}
    case 'Q':{
      for (int y=startY+1; y<=startY+5; y++){
        leds[koordinate_(startX,y)] = CRGB(r,g,b);
        if(y>startY+1)leds[koordinate_(startX+4,y)] = CRGB(r,g,b);
        else leds[koordinate_(startX+4,y-1)] = CRGB(r,g,b);
      }
      for (int x=startX+1; x<=startX+3; x++){
        leds[koordinate_(x,startY+6)] = CRGB(r,g,b);
        if(x<startX+3) leds[koordinate_(x,startY)] = CRGB(r,g,b);
        else leds[koordinate_(x,startY+1)] = CRGB(r,g,b);
      }
      leds[koordinate_(startX+2,startY+2)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case 'R':{
      for (int y=startY; y<=startY+6; y++){
        leds[koordinate_(startX,y)] = CRGB(r,g,b);
      }
      for (int x=startX+1; x<=startX+3; x++){
        leds[koordinate_(x,startY+3)] = CRGB(r,g,b);
        leds[koordinate_(x,startY+6)] = CRGB(r,g,b);
      } 
      leds[koordinate_(startX+2,startY+2)] = CRGB(r,g,b);
      leds[koordinate_(startX+3,startY+1)] = CRGB(r,g,b);
      leds[koordinate_(startX+4,startY)] = CRGB(r,g,b);
      leds[koordinate_(startX+4,startY+4)] = CRGB(r,g,b);
      leds[koordinate_(startX+4,startY+5)] = CRGB(r,g,b);    
      FastLED.show();
      break;}
    case 'S':{
      for (int y=startY+4; y<=startY+5; y++){
        leds[koordinate_(startX,y)] = CRGB(r,g,b);
        leds[koordinate_(startX+4,y-3)] = CRGB(r,g,b);
      } 
      for (int x=startX; x<=startX+3; x++){
        leds[koordinate_(x,startY)] = CRGB(r,g,b);
        leds[koordinate_(x+1,startY+6)] = CRGB(r,g,b);
        if(x>startX)leds[koordinate_(x,startY+3)] = CRGB(r,g,b);
      }   
      FastLED.show();
      break;}
    case 'T':{
      for (int y=startY; y<=startY+6; y++){
        leds[koordinate_(startX+2,y)] = CRGB(r,g,b);
      }
      for (int x=startX; x<=startX+4; x++){
        leds[koordinate_(x,startY+6)] = CRGB(r,g,b);
      }  
      FastLED.show();
      break;}
    case 'U':{
      for (int y=startY+1; y<=startY+6; y++){
        leds[koordinate_(startX,y)] = CRGB(r,g,b);
        leds[koordinate_(startX+4,y)] = CRGB(r,g,b);
      }
      for (int x=startX+1; x<=startX+3; x++){
        leds[koordinate_(x,startY)] = CRGB(r,g,b);
      }    
      FastLED.show();
      break;}
    case 'V':{
      for (int y=startY+3; y<=startY+6; y++){
        leds[koordinate_(startX,y)] = CRGB(r,g,b);
        leds[koordinate_(startX+4,y)] = CRGB(r,g,b);
      }
      for (int x=startX+1; x<=startX+3; x++){
        if (x==startX+2)leds[koordinate_(x,startY)] = CRGB(r,g,b);
        else {leds[koordinate_(x,startY+1)] = CRGB(r,g,b);
              leds[koordinate_(x,startY+2)] = CRGB(r,g,b);}
      }
      FastLED.show();
      break;}
    case 'W':{
      for (int y=startY+1; y<=startY+6; y++){
        leds[koordinate_(startX,y)] = CRGB(r,g,b);
        leds[koordinate_(startX+4,y)] = CRGB(r,g,b);
      } 
      for (int x=startX+1; x<=startX+3; x++){
        if (x==startX+2){leds[koordinate_(x,startY+1)] = CRGB(r,g,b);
                         leds[koordinate_(x,startY+2)] = CRGB(r,g,b);
                         leds[koordinate_(x,startY+3)] = CRGB(r,g,b);}
        else leds[koordinate_(x,startY)] = CRGB(r,g,b);
      }   
      FastLED.show();
      break;}
    case 'X':{
      int cross = 0;
      for (int y=startY+1; y<=startY+5; y++){
        leds[koordinate_(startX+cross,y)] = CRGB(r,g,b);
        leds[koordinate_(startX+4-cross,y)] = CRGB(r,g,b);
        cross++;
      }
      leds[koordinate_(startX,startY)] = CRGB(r,g,b);
      leds[koordinate_(startX+4,startY)] = CRGB(r,g,b);
      leds[koordinate_(startX,startY+6)] = CRGB(r,g,b);
      leds[koordinate_(startX+4,startY+6)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case 'Y':{
    for (int y=startY+4; y<=startY+6; y++){
        leds[koordinate_(startX,y)] = CRGB(r,g,b);
        leds[koordinate_(startX+4,y)] = CRGB(r,g,b);
        leds[koordinate_(startX+2,y-4)] = CRGB(r,g,b);
      }
      leds[koordinate_(startX+1,startY+3)] = CRGB(r,g,b);
      leds[koordinate_(startX+3,startY+3)] = CRGB(r,g,b);  
      FastLED.show();
      break;}
    case 'Z':{
      int dia = 1;
      for (int x=startX; x<=startX+4; x++){
        leds[koordinate_(x,startY)] = CRGB(r,g,b);
        leds[koordinate_(x,startY+6)] = CRGB(r,g,b);
        leds[koordinate_(x,startY+dia)] = CRGB(r,g,b);
        dia++;
      } 
      FastLED.show();
      break;}/*
    case 'a':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case 'b':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case 'c':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case 'd':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case 'e':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case 'f':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case 'g':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case 'h':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case 'i':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case 'j':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case 'k':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case 'l':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case 'm':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case 'n':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case 'o':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case 'p':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case 'q':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case 'r':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case 's':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case 't':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case 'u':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case 'v':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case 'w':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case 'x':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case 'y':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case 'z':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case '0':{
      for (int y=startY+1; y<=startY+5; y++){
        leds[koordinate_(startX,y)] = CRGB(r,g,b);
        leds[koordinate_(startX+4,y)] = CRGB(r,g,b);
      }
      int ho = 0;
      for (int x=startX+1; x<=startX+3; x++){
        leds[koordinate_(x,startY)] = CRGB(r,g,b);
        leds[koordinate_(x,startY+6)] = CRGB(r,g,b);
        leds[koordinate_(x,startY+2+ho)] = CRGB(r,g,b);
        ho++;
      } 
      FastLED.show();
      break;}
    case '1':{
      for (int y=startY+1; y<=startY+6; y++){
        leds[koordinate_(startX+2,y)] = CRGB(r,g,b);
      }
      for (int x=startX+1; x<=startX+3; x++){
        leds[koordinate_(x,startY)] = CRGB(r,g,b);
        if(x==startX+1)leds[koordinate_(x,startY+5)] = CRGB(r,g,b);
      }
      FastLED.show();
      break;}
    case '2':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case '3':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case '4':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case '5':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case '6':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case '7':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case '8':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case '9':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case '$':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case '+':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case '-':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case '*':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case '/':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case '=':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case '%':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case '?':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case '`':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case ':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case '´':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case '#':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case '@':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case '&':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case '_':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case '(':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case ')':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case ',':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case '.':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case ';':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case ':':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case '!':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case '|':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case '{':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case '}':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case '<':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case '>':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case '[':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case ']':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case '^':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;}
    case '~':{ //TO DO
      leds[koordinate_(startX-1,startY-1)] = CRGB(r,g,b);
      FastLED.show();
      break;} */
    default:
      leds[koordinate_(9,9)] = CRGB(r,g,b);
      leds[koordinate_(0,9)] = CRGB(r,g,b);   
      FastLED.show();
      break;
  }
  
}



/* koordinate_nsystem */
int koordinate_(int x, int y){
  int leuchte;
  switch (x) {
    case 0:
      if (y==0){leuchte = 9; break;}
      else if (y==1){leuchte = 10; break;}
           else if (y==2){leuchte = 29; break;}
                else if (y==3){leuchte = 30; break;} 
                     else if (y==4){leuchte = 49; break;}
                          else if (y==5){leuchte = 50; break;}
                               else if (y==6){leuchte = 69; break;}
                                    else if (y==7){leuchte = 70; break;}
                                         else if (y==8){leuchte = 89; break;}
                                              else if (y==9){leuchte = 90; break;}    
    case 1:
      if (y==0){leuchte = 8; break;}
      else if (y==1){leuchte = 11; break;}
           else if (y==2){leuchte = 28; break;}
                else if (y==3){leuchte = 31; break;} 
                     else if (y==4){leuchte = 48; break;}
                          else if (y==5){leuchte = 51; break;}
                               else if (y==6){leuchte = 68; break;}
                                    else if (y==7){leuchte = 71; break;}
                                         else if (y==8){leuchte = 88; break;}
                                              else if (y==9){leuchte = 91; break;} 
      break;
    case 2:
      if (y==0){leuchte = 7; break;}
      else if (y==1){leuchte = 12; break;}
           else if (y==2){leuchte = 27; break;}
                else if (y==3){leuchte = 32; break;} 
                     else if (y==4){leuchte = 47; break;}
                          else if (y==5){leuchte = 52; break;}
                               else if (y==6){leuchte = 67; break;}
                                    else if (y==7){leuchte = 72; break;}
                                         else if (y==8){leuchte = 87; break;}
                                              else if (y==9){leuchte = 92; break;}
      break;
    case 3:
      if (y==0){leuchte = 6; break;}
      else if (y==1){leuchte = 13; break;}
           else if (y==2){leuchte = 26; break;}
                else if (y==3){leuchte = 33; break;} 
                     else if (y==4){leuchte = 46; break;}
                          else if (y==5){leuchte = 53; break;}
                               else if (y==6){leuchte = 66; break;}
                                    else if (y==7){leuchte = 73; break;}
                                         else if (y==8){leuchte = 86; break;}
                                              else if (y==9){leuchte = 93; break;}
      break;    
    case 4:
      if (y==0){leuchte = 5; break;}
      else if (y==1){leuchte = 14; break;}
           else if (y==2){leuchte = 25; break;}
                else if (y==3){leuchte = 34; break;} 
                     else if (y==4){leuchte = 45; break;}
                          else if (y==5){leuchte = 54; break;}
                               else if (y==6){leuchte = 65; break;}
                                    else if (y==7){leuchte = 74; break;}
                                         else if (y==8){leuchte = 85; break;}
                                              else if (y==9){leuchte = 94; break;}
      break;
    case 5:
      if (y==0){leuchte = 4; break;}
      else if (y==1){leuchte = 15; break;}
           else if (y==2){leuchte = 24; break;}
                else if (y==3){leuchte = 35; break;} 
                     else if (y==4){leuchte = 44; break;}
                          else if (y==5){leuchte = 55; break;}
                               else if (y==6){leuchte = 64; break;}
                                    else if (y==7){leuchte = 75; break;}
                                         else if (y==8){leuchte = 84; break;}
                                              else if (y==9){leuchte = 95; break;}
      break;
    case 6:
      if (y==0){leuchte = 3; break;}
      else if (y==1){leuchte = 16; break;}
           else if (y==2){leuchte = 23; break;}
                else if (y==3){leuchte = 36; break;} 
                     else if (y==4){leuchte = 43; break;}
                          else if (y==5){leuchte = 56; break;}
                               else if (y==6){leuchte = 63; break;}
                                    else if (y==7){leuchte = 76; break;}
                                         else if (y==8){leuchte = 83; break;}
                                              else if (y==9){leuchte = 96; break;}
      break;
    case 7:
      if (y==0){leuchte = 2; break;}
      else if (y==1){leuchte = 17; break;}
           else if (y==2){leuchte = 22; break;}
                else if (y==3){leuchte = 37; break;} 
                     else if (y==4){leuchte = 42; break;}
                          else if (y==5){leuchte = 57; break;}
                               else if (y==6){leuchte = 62; break;}
                                    else if (y==7){leuchte = 77; break;}
                                         else if (y==8){leuchte = 82; break;}
                                              else if (y==9){leuchte = 97; break;}
      break;
    case 8:
      if (y==0){leuchte = 1; break;}
      else if (y==1){leuchte = 18; break;}
           else if (y==2){leuchte = 21; break;}
                else if (y==3){leuchte = 38; break;} 
                     else if (y==4){leuchte = 41; break;}
                          else if (y==5){leuchte = 58; break;}
                               else if (y==6){leuchte = 61; break;}
                                    else if (y==7){leuchte = 78; break;}
                                         else if (y==8){leuchte = 81; break;}
                                              else if (y==9){leuchte = 98; break;}
      break;
    case 9:
      if (y==0){leuchte = 0; break;}
      else if (y==1){leuchte = 19; break;}
           else if (y==2){leuchte = 20; break;}
                else if (y==3){leuchte = 39; break;} 
                     else if (y==4){leuchte = 40; break;}
                          else if (y==5){leuchte = 59; break;}
                               else if (y==6){leuchte = 60; break;}
                                    else if (y==7){leuchte = 79; break;}
                                         else if (y==8){leuchte = 80; break;}
                                              else if (y==9){leuchte = 99; break;}
      break;    
    default:
      leuchte = 0;
  }
  return leuchte;
}
