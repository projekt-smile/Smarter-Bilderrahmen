#ifndef alphabet_h
#define alphabet_h
#include <Arduino.h>
#include "koordinatenSystem.h"
#include "FastLED.h"
/*
#define DATA_PIN 5
#define NUM_LEDS 100
CRGB leds[NUM_LEDS];
*/

// num_leds enthaelt pixel fuer Buchstaben - leds anzahl pixel bilderrahmen
void clean(uint8_t num_leds);
int koordinate_(int x, int y);
void buchstabe(String letter_s, int r, int g, int b, int startX, int startY, uint8_t num_leds, CRGB* leds);

//enum Alphabet { UNDEF, RED, ORANGE, YELLOW, GREEN,  BLUE, PURPLE };


#endif