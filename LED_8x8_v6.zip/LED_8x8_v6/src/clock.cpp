#include "clock.h"


#define BCD2DEC(val) ((uint8_t) (((val) / 16 * 10) + ((val) % 16)))

static uint8_t bcdToDec( uint8_t val )
{
   return (uint8_t) ((val / 16 * 10) + (val % 16));
}

static uint8_t hour;
static uint8_t minute;
static uint8_t second;

void updateTime() {
	Wire.beginTransmission(RTC_I2C_ADDRESS); //Aufbau der Verbindung zur Adresse 0x68
	Wire.write(0);
	Wire.endTransmission();
 
	Wire.requestFrom(RTC_I2C_ADDRESS, 7);
	second = bcdToDec(Wire.read() & 0x7f);
	minute = bcdToDec(Wire.read()); 
	hour  = bcdToDec(Wire.read() & 0x3f);
}

uint8_t getHour() {
	return hour;
}

uint8_t getMinute() {
	return minute;
}

uint8_t getSecond() {
	return second;
}
