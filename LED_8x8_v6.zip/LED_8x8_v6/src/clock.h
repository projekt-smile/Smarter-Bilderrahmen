#ifndef clock_cpp
#define clock_cpp

#include <Arduino.h>
#include <Wire.h>

#define RTC_I2C_ADDRESS 0x68 // I2C Adresse des RTC  DS3231

void updateTime();
uint8_t getHour();
uint8_t getMinute();
uint8_t getSecond();

#endif